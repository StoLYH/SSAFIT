<template>
  <div class="divider-bar"></div>
</template>

<script setup>
</script>

<style scoped>
.divider-bar {
  width: 100%;
  max-width: 1150px;
  height: 100px;
  background: linear-gradient(90deg, #e0e0e0 0%, #222 100%);
  margin: 48px auto 0 auto;
  border: none;
  z-index: 1;
}
</style> 